package controlador;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import modelo.Modelo;
import vista.Menu1;
import vista.MenuCanino;
import vista.MenuFelino;
import vista.MenuLista;

public class Controlador implements ActionListener {

    Menu1 menu1;
    Modelo modelo;
    MenuCanino menuCanino;
    MenuFelino menuFelino;
    MenuLista menuLista;

    public ArrayList<Modelo> agregarMascota = new ArrayList<>();
    
    private void llenarTabla(){
        DefaultTableModel modeloDefault = new DefaultTableModel(new String[]{"Nombre","Raza","Edad","Color","Toxoplasmosis","Nivel Entrenamiento"},agregarMascota.size());
        menuLista.jTableMascotas.setModel(modeloDefault);
        
        TableModel tablaMas = menuLista.jTableMascotas.getModel();
        for(int i = 0; i< agregarMascota.size(); i++){
            Modelo modelo = agregarMascota.get(i);
            tablaMas.setValueAt(modelo.getNombre(), i, 0);
            tablaMas.setValueAt(modelo.getRaza(), i, 1);
            tablaMas.setValueAt(modelo.getEdad(), i, 2);
            tablaMas.setValueAt(modelo.getColor(), i, 3);
            tablaMas.setValueAt(modelo.getToxo(), i, 4);
            tablaMas.setValueAt(modelo.getEntrenamiento(), i, 5);
            
        }
        
    }
    

    public Controlador(Menu1 menu1, Modelo modelo, MenuCanino menuCanino, MenuFelino menuFelino, MenuLista menuLista) {
        this.menu1 = menu1;
        this.modelo = modelo;
        this.menuCanino = menuCanino;
        this.menuFelino = menuFelino;
        this.menuLista = menuLista;
        this.menuCanino.jButtonRegistrarCanino.addActionListener(this);
        this.menuFelino.jButtonRegistrarFelino.addActionListener(this);
        this.menuLista.jButtonVolverMenuLista.addActionListener(this);
        this.menuCanino.jButton1VolverCanino.addActionListener(this);
        this.menuFelino.jButton1VolverFelino.addActionListener(this);
        this.menu1.jButtonAgregarCanino.addActionListener(this);
        this.menu1.jButtonAgregarFelino.addActionListener(this);
        this.menu1.jButtonConsultarMascotaDisponible.addActionListener(this);
        this.menuLista.jButtonEliminar.addActionListener(this);
    }

    public void iniciarPrograma() {
        menu1.setTitle("Hogar de Mascotas");
        menu1.setLocationRelativeTo(null);
        menu1.setVisible(true);

    }

   Modelo acumular = new Modelo();
   
    
    @Override
    public void actionPerformed(ActionEvent caja) {
        if(menu1.jButtonAgregarFelino == caja.getSource())
        {
            menuFelino.setVisible(true);
            menuFelino.setLocationRelativeTo(null);
            
            menu1.dispose();
        }
        
        if(menu1.jButtonAgregarCanino == caja.getSource())
        {
            menuCanino.setVisible(true);
            menuCanino.setLocationRelativeTo(null);
            
            menu1.dispose();
        }
        
        if(menu1.jButtonConsultarMascotaDisponible == caja.getSource())
        {
            menuLista.setVisible(true);
            menuLista.setLocationRelativeTo(null);
            
            menu1.dispose();
        }
        
        if(menu1.jButtonConsultarMascotaDisponible == caja.getSource())
        {
            menuLista.setVisible(true);
            menuLista.setLocationRelativeTo(null);
            
            menu1.dispose();
        }
        
        if (menuCanino.jButtonRegistrarCanino == caja.getSource()) {
            
            Modelo can = new Modelo();

            can.setNombre(menuCanino.jTextFieldNombreCanino.getText());
            can.setRaza(menuCanino.jTextFieldRazaCanino.getText());
            can.setEdad(Integer.parseInt(menuCanino.jTextFieldEdadCanino.getText()));
            can.setColor(menuCanino.jTextFieldColorCanino.getText());
            can.setEntrenamiento(Integer.parseInt(menuCanino.jTextFieldAñosEntrenamientoCanino.getText()));
            acumular.setAcumCantCaninos(acumular.getAcumCantCaninos()+1);
            acumular.setAcumEdad(acumular.getAcumEdad()+can.getEdad());
            can.setTipoM("Canino");
 
            agregarMascota.add(can);
            
            menuCanino.jTextFieldNombreCanino.setText("");
            menuCanino.jTextFieldRazaCanino.setText("");
            menuCanino.jTextFieldEdadCanino.setText("");
            menuCanino.jTextFieldColorCanino.setText("");
            menuCanino.jTextFieldAñosEntrenamientoCanino.setText("");
            JOptionPane.showMessageDialog(null,"Mascota Registrada!");
        }
        
        if (menuFelino.jButtonRegistrarFelino == caja.getSource()) {
            Modelo fel = new Modelo();

            fel.setNombre(menuFelino.jTextFieldNombreFelino.getText());
            fel.setRaza(menuFelino.jTextFieldRazaFelino.getText());
            fel.setEdad(Integer.parseInt(menuFelino.jTextFieldEdadFelino.getText()));
            fel.setColor(menuFelino.jTextFieldColorFelino.getText());
            fel.setToxo(menuFelino.jTextFieldToxo.getText());
            acumular.setAcumCantFelinos(acumular.getAcumCantFelinos()+1);
            acumular.setAcumEdad(acumular.getAcumEdad()+fel.getEdad());
            fel.setTipoM("Felino");
            
            agregarMascota.add(fel);
            
            menuFelino.jTextFieldNombreFelino.setText("");
            menuFelino.jTextFieldRazaFelino.setText("");
            menuFelino.jTextFieldEdadFelino.setText("");
            menuFelino.jTextFieldColorFelino.setText("");
            menuFelino.jTextFieldToxo.setText("");
            
            JOptionPane.showMessageDialog(null,"Mascota Registrada!");
        }
        
        if(menuFelino.jButton1VolverFelino == caja.getSource())
        {
            menu1.setVisible(true);
            menu1.setLocationRelativeTo(null);
            
            menuFelino.dispose();
        }
        
        if(menuCanino.jButton1VolverCanino == caja.getSource())
        {
            menu1.setVisible(true);
            menu1.setLocationRelativeTo(null);
            
            menuCanino.dispose();
        }
        
        if(menuLista.jButtonVolverMenuLista == caja.getSource())
        {
            menu1.setVisible(true);
            menu1.setLocationRelativeTo(null);
            
            menuLista.dispose();
        }
        
         if(menu1.jButtonConsultarMascotaDisponible == caja.getSource())
        {
            menuLista.setVisible(true);
            menuLista.setLocationRelativeTo(null);
            
            menu1.dispose();
            if(agregarMascota.size() == 0){
                JOptionPane.showMessageDialog(null, "No hay mascotas registradas!!!"+"\nPor favor Registre alguna mascota.");
            }else{
                acumular.setPromedioEdad(acumular.getAcumEdad()/agregarMascota.size());
                menuLista.jTextFieldPromedioEdadMascotas.setText(acumular.getPromedioEdad()+"");
                menuLista.jTextFieldTotalCantCaninos.setText(acumular.getAcumCantCaninos()+"");
                menuLista.jTextFieldTotalCantFelinos.setText(acumular.getAcumCantFelinos()+"");
            }
            llenarTabla();
 
        }
         
        if(menuLista.jButtonEliminar == caja.getSource())
        {
            int ef = menuLista.jTableMascotas.getSelectedRow();
            Modelo elementoEliminar = agregarMascota.get(ef);
            if(ef >= 0 )
            {
                agregarMascota.remove(ef);
                llenarTabla();
                
                if(elementoEliminar.getTipoM().equals("Felino"))
                {
                    acumular.setAcumCantFelinos(acumular.getAcumCantFelinos() - 1);
                }
                else
                {
                    acumular.setAcumCantCaninos(acumular.getAcumCantCaninos() - 1);
                }
                acumular.setAcumEdad(acumular.getAcumEdad()-elementoEliminar.getEdad());
            }
            JOptionPane.showMessageDialog(null, "Ha sido eliminado satisfactoriamente.");
            menu1.setVisible(true);
            menu1.setLocationRelativeTo(null);
            
            menuLista.dispose();
        }
         
        
    }
    
    
    
}
