
package main;

import controlador.Controlador;
import modelo.Modelo;
import vista.Menu1;
import vista.MenuCanino;
import vista.MenuFelino;
import vista.MenuLista;

public class Ejecutar {
    public static void main(String[] args) {
        Modelo modelo = new Modelo();
        Menu1 menu1 = new Menu1();
        MenuCanino menuCanino = new MenuCanino();
        MenuFelino menuFelino = new MenuFelino();
        MenuLista menuLista = new MenuLista();
        Controlador control = new Controlador(menu1, modelo, menuCanino, menuFelino, menuLista);
        control.iniciarPrograma();
        
    }
}
