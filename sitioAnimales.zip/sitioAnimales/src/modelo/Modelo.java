
package modelo;

public class Modelo {
    
    private String nombre;
    private String tipoM;
    private String raza;
    private String color;
    private int edad;
    private String toxo;
    private int entrenamiento;
    private int promedioEdad=0;
    private int cantFelinos=0;
    private int cantCaninos=0;
    private int acumEdad=0;
    private int acumCantFelinos=0;
    private int acumCantCaninos=0;

    public String getTipoM() {
        return tipoM;
    }

    public void setTipoM(String tipoM) {
        this.tipoM = tipoM;
    }


    
    
    public void setPromedioEdad(int promedioEdad) {
        this.promedioEdad = promedioEdad;
    }

    public void setCantFelinos(int cantFelinos) {
        this.cantFelinos = cantFelinos;
    }

    public void setCantCaninos(int cantCaninos) {
        this.cantCaninos = cantCaninos;
    }

    public void setAcumEdad(int acumEdad) {
        this.acumEdad = acumEdad;
    }

    public void setAcumCantFelinos(int acumCantFelinos) {
        this.acumCantFelinos = acumCantFelinos;
    }

    public void setAcumCantCaninos(int acumCantCaninos) {
        this.acumCantCaninos = acumCantCaninos;
    }

    public int getAcumEdad() {
        return acumEdad;
    }

    public int getAcumCantFelinos() {
        return acumCantFelinos;
    }

    public int getAcumCantCaninos() {
        return acumCantCaninos;
    }

    public int getPromedioEdad() {
        return promedioEdad;
    }

    public int getCantFelinos() {
        return cantFelinos;
    }

    public int getCantCaninos() {
        return cantCaninos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getToxo() {
        return toxo;
    }

    public void setToxo(String toxo) {
        this.toxo = toxo;
    }

    public int getEntrenamiento() {
        return entrenamiento;
    }

    public void setEntrenamiento(int entrenamiento) {
        this.entrenamiento = entrenamiento;
    }
    
    
    
    
    
}
